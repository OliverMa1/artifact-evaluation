# This file was generated from setup.py
version = '1.3.0'
