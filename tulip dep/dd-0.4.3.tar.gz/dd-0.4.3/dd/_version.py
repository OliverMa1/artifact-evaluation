# This file was generated from setup.py
version = '0.4.3'
