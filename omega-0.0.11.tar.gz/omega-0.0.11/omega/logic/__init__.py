"""Parser and bitblaster for first-order temporal logic."""
