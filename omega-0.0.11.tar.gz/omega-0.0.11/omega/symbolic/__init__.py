"""Algorithms and data structures using decision diagrams."""
